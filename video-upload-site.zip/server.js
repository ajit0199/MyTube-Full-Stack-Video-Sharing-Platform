require('dotenv').config();
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

const app = express();

if (!fs.existsSync('uploads')) fs.mkdirSync('uploads');

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});
db.connect(err => {
  if (err) console.error('MySQL Error:', err);
  else console.log('MySQL connected');
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static('public'));

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser((id, done) => {
  db.query('SELECT * FROM users WHERE id = ?', [id], (err, results) => {
    if (err) return done(err);
    done(null, results[0]);
  });
});

passport.use(new LocalStrategy({ usernameField: 'email' }, (email, password, done) => {
  db.query('SELECT * FROM users WHERE email = ? AND google_id IS NULL', [email], (err, results) => {
    if (err) return done(err);
    if (results.length === 0) return done(null, false, { message: 'Incorrect email or password' });

    bcrypt.compare(password, results[0].password, (err, isMatch) => {
      if (err) return done(err);
      if (isMatch) return done(null, results[0]);
      return done(null, false, { message: 'Incorrect email or password' });
    });
  });
}));

passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: "/auth/google/callback"
}, (accessToken, refreshToken, profile, done) => {
  db.query('SELECT * FROM users WHERE google_id = ?', [profile.id], (err, results) => {
    if (err) return done(err);
    if (results.length > 0) return done(null, results[0]);

    const newUser = {
      google_id: profile.id,
      name: profile.displayName,
      email: profile.emails[0].value,
      photo_url: profile.photos[0].value,
      is_admin: 0
    };
    db.query('INSERT INTO users SET ?', newUser, (err, result) => {
      if (err) return done(err);
      newUser.id = result.insertId;
      done(null, newUser);
    });
  });
}));

app.post('/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).send('Missing fields');

  db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err) return res.status(500).send('DB error');
    if (results.length > 0) return res.status(400).send('Email already exists');

    bcrypt.hash(password, 10, (err, hash) => {
      if (err) return res.status(500).send('Server error');

      const newUser = { name, email, password: hash, is_admin: 0 };
      db.query('INSERT INTO users SET ?', newUser, (err) => {
        if (err) return res.status(500).send('DB error');
        res.redirect('/login.html');
      });
    });
  });
});

app.post('/login', passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/login.html'
}));

app.get('/auth/google', (req, res, next) => {
  passport.authenticate('google', { scope: ['profile', 'email'], prompt: 'select_account' })(req, res, next);
});
app.get('/auth/google/callback', passport.authenticate('google', { failureRedirect: '/login.html' }), (req, res) => {
  res.redirect('/');
});

app.get('/logout', (req, res) => {
  req.logout(() => res.redirect('/login.html'));
});

app.get('/me', (req, res) => {
  res.json(req.isAuthenticated() ? req.user : null);
});

app.post('/upload', (req, res, next) => {
  if (req.isAuthenticated() && req.user.is_admin) return next();
  return res.status(403).send('Forbidden');
}, upload.single('video'), (req, res) => {
  const { title, description } = req.body;
  if (!req.file) return res.status(400).send('No video uploaded');

  const filePath = req.file.path.replace(/\\/g, "/");
  const thumbPath = `uploads/thumb-${Date.now()}.jpg`;
  const ffmpegCommand = `ffmpeg -i "${filePath}" -ss 00:00:02.000 -vframes 1 "${thumbPath}"`;

  exec(ffmpegCommand, (err) => {
    if (err) {
      console.error("FFMPEG Error:", err);
      return res.status(500).send("Thumbnail generation failed.");
    }

    const sql = `
      INSERT INTO videos (user_id, title, description, file_path, thumbnail_path)
      VALUES (?, ?, ?, ?, ?)`;
    const values = [req.user.id, title, description, filePath, thumbPath];

    db.query(sql, values, (err) => {
      if (err) return res.status(500).send('DB error');
      res.status(200).send('Video uploaded successfully');
    });
  });
});

app.get('/videos', (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json([]);
  const sql = `
    SELECT v.*,
      (SELECT COUNT(*) FROM likes WHERE video_id = v.id) AS likes
    FROM videos v
    ORDER BY upload_time DESC`;
  db.query(sql, (err, results) => {
    if (err) return res.status(500).send('DB error');
    res.json(results);
  });
});

app.post('/videos/:id/like', (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).send('Unauthorized');
  const videoId = req.params.id;

  db.query('SELECT * FROM likes WHERE video_id = ? AND user_id = ?', [videoId, req.user.id], (err, results) => {
    if (err) return res.status(500).send('DB error');

    if (results.length > 0) {
      db.query('DELETE FROM likes WHERE video_id = ? AND user_id = ?', [videoId, req.user.id], (err) => {
        if (err) return res.status(500).send('DB error');
        res.json({ liked: false });
      });
    } else {
      db.query('INSERT INTO likes (video_id, user_id) VALUES (?, ?)', [videoId, req.user.id], (err) => {
        if (err) return res.status(500).send('DB error');
        res.json({ liked: true });
      });
    }
  });
});

app.get('/videos/:id/comments', (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json([]);
  const videoId = req.params.id;
  db.query('SELECT * FROM comments WHERE video_id = ? ORDER BY created_at DESC', [videoId], (err, results) => {
    if (err) return res.status(500).send('DB error');
    res.json(results);
  });
});

app.post('/videos/:id/comments', (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).send('Unauthorized');
  const videoId = req.params.id;
  const content = req.body.content;
  if (!content) return res.status(400).send('Missing content');
  db.query('INSERT INTO comments (video_id, user_id, content) VALUES (?, ?, ?)', [videoId, req.user.id, content], (err) => {
    if (err) return res.status(500).send('DB error');
    res.sendStatus(200);
  });
});

app.use((req, res, next) => {
  if (req.isAuthenticated() || req.path.startsWith('/auth') || req.path.endsWith('.html')) return next();
  res.redirect('/login.html');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
